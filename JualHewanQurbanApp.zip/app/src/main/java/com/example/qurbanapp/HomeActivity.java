
package com.example.qurbanapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.qurbanapp.adapter.HewanAdapter;
import com.example.qurbanapp.model.HewanQurban;
import java.util.ArrayList;

public class HomeActivity extends AppCompatActivity {
    RecyclerView rvHewan;
    ArrayList<HewanQurban> listHewan = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        rvHewan = findViewById(R.id.rvHewan);
        rvHewan.setLayoutManager(new LinearLayoutManager(this));

        listHewan.add(new HewanQurban("Sapi Bali", "Sapi", "Rp 18.000.000"));
        listHewan.add(new HewanQurban("Kambing Etawa", "Kambing", "Rp 3.000.000"));

        HewanAdapter adapter = new HewanAdapter(listHewan, this);
        rvHewan.setAdapter(adapter);
    }
}
