
package com.example.qurbanapp.model;

public class HewanQurban {
    private String nama;
    private String jenis;
    private String harga;

    public HewanQurban(String nama, String jenis, String harga) {
        this.nama = nama;
        this.jenis = jenis;
        this.harga = harga;
    }

    public String getNama() { return nama; }
    public String getJenis() { return jenis; }
    public String getHarga() { return harga; }
}
